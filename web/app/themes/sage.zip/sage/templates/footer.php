<footer class="content-info">
  <div class="container">
      <div class="row">
          <?php dynamic_sidebar('sidebar-footer1'); ?>
          <?php dynamic_sidebar('sidebar-footer2'); ?>
          <?php dynamic_sidebar('sidebar-footer3'); ?>
      </div>
  </div>
</footer>
